export const mainDebug = {
  template: require('./debug.html'),
  bindings: {
    game: '<'
  }
};

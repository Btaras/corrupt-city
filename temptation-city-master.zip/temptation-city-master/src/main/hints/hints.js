export const mainHints = {
  template: require('./hints.html'),
  bindings: {
    game: '<'
  }
};

export const mainToolbar = {
  template: require('./toolbar.html'),
  bindings: {
    game: '<'
  }
};

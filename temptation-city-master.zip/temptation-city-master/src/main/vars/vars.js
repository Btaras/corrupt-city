export const mainVars = {
  template: require('./vars.html'),
  bindings: {
    game: '<'
  }
};

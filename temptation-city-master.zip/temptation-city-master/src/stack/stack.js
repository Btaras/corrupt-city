export const stack = {
  template: require('./stack.html'),
  bindings: {
    stack: '<',
    game: '<'
  }
};
